import os

def replace_in_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
        
    # Выполняем все необходимые замены
    modified_content = (
        content
        .replace(' A ', ' H ')
        .replace('GLY', 'VAL')
        .replace('HTOM', 'ATOM')
    )
    
    with open(file_path, 'w') as file:
        file.write(modified_content)

for i in range(1000):
    filename = f'gen_{i:04d}.pdb'
    if os.path.exists(filename):
        print(f"Произвожу замену в файле {filename}")
        replace_in_file(filename)
